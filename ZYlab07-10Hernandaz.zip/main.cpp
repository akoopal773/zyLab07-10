#include <iostream>
using namespace std;

int main() {

   /* Type your code here. */
   
   // Declaring variables
      
   int userNum;
   int numEntries = 0;
   int maxNum = 0; // Holds the largest number fron numbers entered by user
   int addNum = 0;
   double avrgNum;
   
   cin >> userNum; // Read the first user entry
   
   // Set up a loop for user entries to add numbers and find the largest number.
   
   while (userNum >= 0) {
         maxNum = (userNum > maxNum) ? userNum : maxNum; // Compare keep the largest number
         numEntries = numEntries + 1;
         addNum = addNum + userNum; //Add up user entries for computation of average at the end.
         cin >> userNum; // Continue reading numbers user enters
   }
   // Display results only if there were entries to compute
   
   if (numEntries > 0) {
      avrgNum = addNum / numEntries;
      cout << avrgNum << " " << maxNum << endl; // only for testing << " " << maxNum << endl;
   }
   
         
   
   return 0;
}
